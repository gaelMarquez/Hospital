﻿Imports System.Data
Imports System.Windows.Forms

Public Class frmDoctor
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim frmRec = New frmReceta
        frmRec.Show()
        Hide()
    End Sub
End Class