﻿Imports System.ComponentModel
Imports System.Windows.Forms

Public Class frmNewUsuario
    Dim rol As Integer
    Private Sub NewUsuario_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: esta línea de código carga datos en la tabla 'HospitalHorario.Horario' Puede moverla o quitarla según sea necesario.
        Me.HorarioTableAdapter.Fill(Me.HospitalHorario.Horario)
        'TODO: esta línea de código carga datos en la tabla 'HospitalConsultorio.Consultorio' Puede moverla o quitarla según sea necesario.
        Me.ConsultorioTableAdapter.Fill(Me.HospitalConsultorio.Consultorio)
        'TODO: esta línea de código carga datos en la tabla 'HospitalDataSet1.Especialidad' Puede moverla o quitarla según sea necesario.
        Me.EspecialidadTableAdapter.Fill(Me.HospitalDataSet1.Especialidad)
        Me.cargar()
    End Sub

    Private Sub comboTipo_SelectedIndexChanged(sender As Object, e As EventArgs) Handles comboTipo.SelectedIndexChanged
        Select Case Me.comboTipo.SelectedValue
            Case 1
                Me.GroupDoctor.Visible = False
            Case 2
                Me.GroupDoctor.Visible = False
            Case 3
                Me.GroupDoctor.Visible = True
            Case 4
                Me.GroupDoctor.Visible = False
            Case Else
                Me.GroupDoctor.Visible = False
        End Select

    End Sub

    Private Sub frmNewUsuario_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: esta línea de código carga datos en la tabla 'Hospital_Rol.Rol' Puede moverla o quitarla según sea necesario.
        Me.RolTableAdapter.Fill(Me.Hospital_Rol.Rol)
        Me.GroupDoctor.Visible = False
    End Sub

    Private Sub cmdNew_Click(sender As Object, e As EventArgs) Handles cmdNew.Click
        Dim cn As New DB_Class
        Dim fechaNac As String = CalFechaNac.Value.Date.ToString("yyyy-MM-dd")
        Try
            If comboTipo.SelectedValue = 3 Then
                cn.EjecutarConsulta("INSERT INTO USUARIO VALUES('" & txtUser.Text & "', '" & comboTipo.SelectedValue & "', '" & comboEspe.SelectedValue &
                                "', '" & ComboHorario.SelectedValue & "', '" & comboCons.SelectedValue & "', '" & txtPass.Text & "', '" & txtName.Text & "', '" &
                                txtPaterno.Text & "', '" & txtMaterno.Text & "', '" & txtTel.Text & "', '" & txtCorreo.Text & "', '" & fechaNac & "')")
            Else
                cn.EjecutarConsulta("INSERT INTO USUARIO VALUES('" & txtUser.Text & "', '" & comboTipo.SelectedValue & "', NULL, NULL, NULL, '" &
                                txtPass.Text & "', '" & txtName.Text & "', '" & txtPaterno.Text & "', '" & txtMaterno.Text & "', '" & txtTel.Text & "', '" &
                                txtCorreo.Text & "', '" & fechaNac & "')")
            End If
            If cn.Err Then
                MsgBox(cn.ErrMessage)
            Else
                MsgBox("Usuario creado correctamente.")
                txtCorreo.Clear()
                txtMaterno.Clear()
                txtName.Clear()
                txtPass.Clear()
                txtTel.Clear()
                txtUser.Clear()
                txtPaterno.Clear()
                Me.comboCons.SelectedIndex = 0
                Me.comboEspe.SelectedIndex = 0
                Me.ComboHorario.SelectedIndex = 0
                Me.comboTipo.SelectedIndex = 0
            End If
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            cn = Nothing
        End Try
    End Sub

    Private Sub cargar()
        Dim conexion As New DB_Class
        Me.ComboHorario.DataSource = conexion.EjecutarConsulta("SELECT ID_Horario, TRIM(Turno) + ' '  + CONVERT(VARCHAR(5), HoraIn, 108) + ' | ' + CONVERT(VARCHAR(5), HoraFn, 108) AS Turno FROM dbo.Horario")
        Me.ComboHorario.DisplayMember = "Turno"
        Me.ComboHorario.ValueMember = "ID_Horario"
        conexion = Nothing
    End Sub

    Private Sub frmNewUsuario_Closing(sender As Object, e As CancelEventArgs) Handles Me.Closing
        Dim _frmLogIn = New frmLogIn
        _frmLogIn.Show()
        Hide()
    End Sub
End Class