﻿Module Module_General
    Public user As String
    Public Function SumaDosNumeros(ByVal _valor1 As Integer, ByVal _valor2 As Integer) As Integer
        Return _valor1 + _valor2
    End Function


End Module
