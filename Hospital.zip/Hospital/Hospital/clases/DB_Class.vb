﻿Imports System.Data
Imports System.Data.SqlClient

Public Class DB_Class
    Private cadenaConexion As String
    Private conexion As SqlConnection

    Public Property Err As Boolean
    Public Property ErrMessage As String

    Public Sub New()
        ' Ajusta la cadena de conexión según tu configuración
        ' cadenaConexion = "Data Source=localhost;Initial Catalog=Hospital;User ID=sa;Password=123"
        cadenaConexion = "Data Source=localhost\SQLEXPRESS;Initial Catalog=Hospital;User ID=sa;Password=123"
        conexion = New SqlConnection(cadenaConexion)
    End Sub

    Private Sub AbrirConexion()
        Try
            If conexion.State = ConnectionState.Closed Then
                conexion.Open()
                Console.WriteLine("Conexión abierta correctamente.")
            End If
        Catch ex As Exception
            Me.Err = True
            Me.ErrMessage = ex.Message
            Console.WriteLine("Error al abrir la conexión: " & ex.Message)
        End Try
    End Sub

    Private Sub CerrarConexion()
        Try
            If conexion.State = ConnectionState.Open Then
                conexion.Close()
                Console.WriteLine("Conexión cerrada correctamente.")
            End If
        Catch ex As Exception
            Me.Err = True
            Me.ErrMessage = ex.Message
            Console.WriteLine("Error al cerrar la conexión: " & ex.Message)
        End Try
    End Sub

    Public Function EjecutarConsulta(ByVal consulta As String) As DataTable
        Dim tabla As New DataTable()

        Try
            AbrirConexion()

            Using adaptador As New SqlDataAdapter(consulta, conexion)
                adaptador.Fill(tabla)
            End Using

        Catch ex As Exception
            Me.Err = True
            Me.ErrMessage = ex.Message
            Console.WriteLine("Error al ejecutar la consulta: " & ex.Message)
        Finally
            CerrarConexion()
        End Try

        Return tabla
    End Function

End Class
