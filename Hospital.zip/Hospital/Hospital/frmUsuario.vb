﻿Imports System.ComponentModel
Imports System.Data

Public Class frmUsuario
    Private Sub cmdBuscar_Click(sender As Object, e As EventArgs) Handles cmdBuscar.Click
        Dim conexion As New DB_Class
        Dim _datatable As DataTable

        _datatable = conexion.EjecutarConsulta("SELECT * FROM Usuario WHERE ID_Usuario='" & Me.txtUsuarioBuscar.Text & "'")

        If _datatable.Rows.Count > 0 Then '''''REVISAMOS SI EL DATATABLE TRAE REGISTROS OBTENIDOS POR LA CONSULTA
            For i = 0 To _datatable.Rows.Count - 1 '''''RECORREMOS EL DATATABLE
                ''''PARA LAS COLUMNAS QUE NO ACEPTAN NULOS NO ES NECESARIO EL IF ISNULL '''''''''''''''
                Me.txtID_Usuario.Text = _datatable.Rows(i).Item("ID_Usuario")

                ''''PONER UN IF ISNULL PARA LAS COLUMNAS QUE ACEPTAN NULOS ''''''''''''
                If _datatable.Rows(i).IsNull("Nombre") Then
                    Me.txtNombre.Text = ""
                Else
                    Me.txtNombre.Text = _datatable.Rows(i).Item("Nombre")
                End If

                Me.txtID_Usuario.Enabled = True
                Me.txtNombre.Enabled = True
                Exit For '''SALIR DEL FOR SI SOLO QUEREMOS UN REGISTRO
            Next
        Else
            MsgBox("Usuario no encontrado")
        End If


        conexion = Nothing
    End Sub

    Private Sub frmUsuario_Closing(sender As Object, e As CancelEventArgs) Handles Me.Closing
        Dim _frmLogin As New Login

        _frmLogin.Show()
        Hide()
    End Sub
End Class