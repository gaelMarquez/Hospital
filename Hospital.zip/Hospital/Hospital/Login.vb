﻿Public Class Login
    Private Sub Login_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: esta línea de código carga datos en la tabla 'HospitalDataSet.Citas_Medicas' Puede moverla o quitarla según sea necesario.
        ' Me.Citas_MedicasTableAdapter.Fill(Me.HospitalDataSet.Citas_Medicas)
        Me.cargar()
    End Sub

    Private Sub cmdLogin_Click(sender As Object, e As EventArgs) Handles cmdLogin.Click
        Dim _db As New DB_Class
        Dim _resultado As Integer

        '_resultado = SumaDosNumeros(Me.txtIDUsuario.Text, Me.txtPassword.Text)

        MsgBox(SumaDosNumeros(Me.txtIDUsuario.Text, Me.txtPassword.Text))


        'If Me.txtIDUsuario.Text = "prueba" Then
        '    MsgBox("ok")
        '    _db.fnConectar("")
        'Else
        '    MsgBox("false")
        'End If


    End Sub

    Private Sub cargar()
        Dim conexion As New DB_Class
        Me.DataGridView1.DataSource = conexion.EjecutarConsulta("Select * FROM Medicamento")
        conexion = Nothing
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim _formUsuario As New frmUsuario

        _formUsuario.Show()
        Hide()


    End Sub

    Private Sub DataGridView1_CellContentClick(sender As Object, e As Windows.Forms.DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick

    End Sub
End Class