﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmNewUsuario
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.cmdNew = New System.Windows.Forms.Button()
        Me.txtPass = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txtUser = New System.Windows.Forms.TextBox()
        Me.txtPaterno = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.txtName = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.txtCorreo = New System.Windows.Forms.TextBox()
        Me.txtTel = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.txtMaterno = New System.Windows.Forms.TextBox()
        Me.CalFechaNac = New System.Windows.Forms.DateTimePicker()
        Me.comboTipo = New System.Windows.Forms.ComboBox()
        Me.RolBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.Hospital_Rol = New Hospital.Hospital_Rol()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.HospitalDataSet = New Hospital.HospitalDataSet()
        Me.HospitalDataSetBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.HospitalDataSetBindingSource1 = New System.Windows.Forms.BindingSource(Me.components)
        Me.RolTableAdapter = New Hospital.Hospital_RolTableAdapters.RolTableAdapter()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.comboEspe = New System.Windows.Forms.ComboBox()
        Me.EspecialidadBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.HospitalDataSet1 = New Hospital.HospitalDataSet1()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.comboCons = New System.Windows.Forms.ComboBox()
        Me.ConsultorioBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.HospitalConsultorio = New Hospital.HospitalConsultorio()
        Me.GroupDoctor = New System.Windows.Forms.GroupBox()
        Me.ComboHorario = New System.Windows.Forms.ComboBox()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.EspecialidadTableAdapter = New Hospital.HospitalDataSet1TableAdapters.EspecialidadTableAdapter()
        Me.ConsultorioTableAdapter = New Hospital.HospitalConsultorioTableAdapters.ConsultorioTableAdapter()
        Me.HospitalHorario = New Hospital.HospitalHorario()
        Me.HorarioBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.HorarioTableAdapter = New Hospital.HospitalHorarioTableAdapters.HorarioTableAdapter()
        CType(Me.RolBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Hospital_Rol, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.HospitalDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.HospitalDataSetBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.HospitalDataSetBindingSource1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.EspecialidadBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.HospitalDataSet1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ConsultorioBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.HospitalConsultorio, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupDoctor.SuspendLayout()
        CType(Me.HospitalHorario, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.HorarioBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'cmdNew
        '
        Me.cmdNew.Font = New System.Drawing.Font("Franklin Gothic Demi", 12.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdNew.Location = New System.Drawing.Point(305, 399)
        Me.cmdNew.Name = "cmdNew"
        Me.cmdNew.Size = New System.Drawing.Size(118, 32)
        Me.cmdNew.TabIndex = 30
        Me.cmdNew.Text = "Crear cuenta"
        Me.cmdNew.UseVisualStyleBackColor = True
        '
        'txtPass
        '
        Me.txtPass.Font = New System.Drawing.Font("Constantia", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtPass.Location = New System.Drawing.Point(214, 162)
        Me.txtPass.Name = "txtPass"
        Me.txtPass.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.txtPass.Size = New System.Drawing.Size(182, 27)
        Me.txtPass.TabIndex = 12
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Franklin Gothic Demi", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(93, 165)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(115, 24)
        Me.Label3.TabIndex = 11
        Me.Label3.Text = "Contraseña: "
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Franklin Gothic Demi", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(125, 125)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(83, 24)
        Me.Label2.TabIndex = 10
        Me.Label2.Text = "Usuario: "
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Franklin Gothic Heavy", 15.75!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(300, 9)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(144, 26)
        Me.Label1.TabIndex = 9
        Me.Label1.Text = "Nueva cuenta"
        '
        'txtUser
        '
        Me.txtUser.Font = New System.Drawing.Font("Constantia", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtUser.Location = New System.Drawing.Point(214, 125)
        Me.txtUser.Name = "txtUser"
        Me.txtUser.Size = New System.Drawing.Size(182, 27)
        Me.txtUser.TabIndex = 8
        '
        'txtPaterno
        '
        Me.txtPaterno.Font = New System.Drawing.Font("Constantia", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtPaterno.Location = New System.Drawing.Point(214, 228)
        Me.txtPaterno.Name = "txtPaterno"
        Me.txtPaterno.Size = New System.Drawing.Size(182, 27)
        Me.txtPaterno.TabIndex = 18
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Franklin Gothic Demi", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(53, 231)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(152, 24)
        Me.Label4.TabIndex = 17
        Me.Label4.Text = "Apellido Paterno:"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Franklin Gothic Demi", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(125, 198)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(80, 24)
        Me.Label5.TabIndex = 16
        Me.Label5.Text = "Nombre:"
        '
        'txtName
        '
        Me.txtName.Font = New System.Drawing.Font("Constantia", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtName.Location = New System.Drawing.Point(214, 195)
        Me.txtName.Name = "txtName"
        Me.txtName.Size = New System.Drawing.Size(182, 27)
        Me.txtName.TabIndex = 15
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Franklin Gothic Demi", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(51, 264)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(157, 24)
        Me.Label6.TabIndex = 25
        Me.Label6.Text = "Apellido Materno:"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Franklin Gothic Demi", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(134, 327)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(71, 24)
        Me.Label7.TabIndex = 24
        Me.Label7.Text = "Correo:"
        '
        'txtCorreo
        '
        Me.txtCorreo.Font = New System.Drawing.Font("Constantia", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtCorreo.Location = New System.Drawing.Point(214, 327)
        Me.txtCorreo.Name = "txtCorreo"
        Me.txtCorreo.Size = New System.Drawing.Size(182, 27)
        Me.txtCorreo.TabIndex = 23
        '
        'txtTel
        '
        Me.txtTel.Font = New System.Drawing.Font("Constantia", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtTel.Location = New System.Drawing.Point(214, 294)
        Me.txtTel.MaxLength = 12
        Me.txtTel.Name = "txtTel"
        Me.txtTel.Size = New System.Drawing.Size(182, 27)
        Me.txtTel.TabIndex = 22
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Franklin Gothic Demi", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(123, 294)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(85, 24)
        Me.Label8.TabIndex = 21
        Me.Label8.Text = "Teléfono:"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Franklin Gothic Demi", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(12, 359)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(196, 24)
        Me.Label9.TabIndex = 20
        Me.Label9.Text = "Fecha de Nacimiento: "
        '
        'txtMaterno
        '
        Me.txtMaterno.Font = New System.Drawing.Font("Constantia", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtMaterno.Location = New System.Drawing.Point(214, 261)
        Me.txtMaterno.Name = "txtMaterno"
        Me.txtMaterno.Size = New System.Drawing.Size(182, 27)
        Me.txtMaterno.TabIndex = 19
        '
        'CalFechaNac
        '
        Me.CalFechaNac.Location = New System.Drawing.Point(214, 360)
        Me.CalFechaNac.MaxDate = New Date(2023, 12, 13, 0, 0, 0, 0)
        Me.CalFechaNac.MinDate = New Date(1915, 1, 1, 0, 0, 0, 0)
        Me.CalFechaNac.Name = "CalFechaNac"
        Me.CalFechaNac.Size = New System.Drawing.Size(200, 20)
        Me.CalFechaNac.TabIndex = 26
        '
        'comboTipo
        '
        Me.comboTipo.DataSource = Me.RolBindingSource
        Me.comboTipo.DisplayMember = "Rol"
        Me.comboTipo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.comboTipo.FormattingEnabled = True
        Me.comboTipo.Location = New System.Drawing.Point(12, 38)
        Me.comboTipo.Name = "comboTipo"
        Me.comboTipo.Size = New System.Drawing.Size(133, 21)
        Me.comboTipo.TabIndex = 30
        Me.comboTipo.ValueMember = "ID_Rol"
        '
        'RolBindingSource
        '
        Me.RolBindingSource.DataMember = "Rol"
        Me.RolBindingSource.DataSource = Me.Hospital_Rol
        '
        'Hospital_Rol
        '
        Me.Hospital_Rol.DataSetName = "Hospital_Rol"
        Me.Hospital_Rol.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Franklin Gothic Demi", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.Location = New System.Drawing.Point(12, 11)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(137, 24)
        Me.Label10.TabIndex = 31
        Me.Label10.Text = "Tipo de Usuario"
        '
        'HospitalDataSet
        '
        Me.HospitalDataSet.DataSetName = "HospitalDataSet"
        Me.HospitalDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'HospitalDataSetBindingSource
        '
        Me.HospitalDataSetBindingSource.DataSource = Me.HospitalDataSet
        Me.HospitalDataSetBindingSource.Position = 0
        '
        'HospitalDataSetBindingSource1
        '
        Me.HospitalDataSetBindingSource1.DataSource = Me.HospitalDataSet
        Me.HospitalDataSetBindingSource1.Position = 0
        '
        'RolTableAdapter
        '
        Me.RolTableAdapter.ClearBeforeFill = True
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Franklin Gothic Demi", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.Location = New System.Drawing.Point(6, 16)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(115, 24)
        Me.Label11.TabIndex = 32
        Me.Label11.Text = "Especialidad"
        '
        'comboEspe
        '
        Me.comboEspe.DataSource = Me.EspecialidadBindingSource
        Me.comboEspe.DisplayMember = "Especialidad"
        Me.comboEspe.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.comboEspe.FormattingEnabled = True
        Me.comboEspe.Location = New System.Drawing.Point(127, 17)
        Me.comboEspe.Name = "comboEspe"
        Me.comboEspe.Size = New System.Drawing.Size(133, 28)
        Me.comboEspe.TabIndex = 33
        Me.comboEspe.ValueMember = "ID_Especialidad"
        '
        'EspecialidadBindingSource
        '
        Me.EspecialidadBindingSource.DataMember = "Especialidad"
        Me.EspecialidadBindingSource.DataSource = Me.HospitalDataSet1
        '
        'HospitalDataSet1
        '
        Me.HospitalDataSet1.DataSetName = "HospitalDataSet1"
        Me.HospitalDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("Franklin Gothic Demi", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.Location = New System.Drawing.Point(16, 60)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(105, 24)
        Me.Label12.TabIndex = 34
        Me.Label12.Text = "Consultorio"
        '
        'comboCons
        '
        Me.comboCons.DataSource = Me.ConsultorioBindingSource
        Me.comboCons.DisplayMember = "Numero"
        Me.comboCons.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.comboCons.FormattingEnabled = True
        Me.comboCons.Location = New System.Drawing.Point(127, 64)
        Me.comboCons.Name = "comboCons"
        Me.comboCons.Size = New System.Drawing.Size(133, 28)
        Me.comboCons.TabIndex = 35
        Me.comboCons.ValueMember = "ID_Consultorio"
        '
        'ConsultorioBindingSource
        '
        Me.ConsultorioBindingSource.DataMember = "Consultorio"
        Me.ConsultorioBindingSource.DataSource = Me.HospitalConsultorio
        '
        'HospitalConsultorio
        '
        Me.HospitalConsultorio.DataSetName = "HospitalConsultorio"
        Me.HospitalConsultorio.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'GroupDoctor
        '
        Me.GroupDoctor.Controls.Add(Me.ComboHorario)
        Me.GroupDoctor.Controls.Add(Me.Label13)
        Me.GroupDoctor.Controls.Add(Me.Label11)
        Me.GroupDoctor.Controls.Add(Me.comboCons)
        Me.GroupDoctor.Controls.Add(Me.Label12)
        Me.GroupDoctor.Controls.Add(Me.comboEspe)
        Me.GroupDoctor.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupDoctor.Location = New System.Drawing.Point(470, 104)
        Me.GroupDoctor.Name = "GroupDoctor"
        Me.GroupDoctor.Size = New System.Drawing.Size(269, 151)
        Me.GroupDoctor.TabIndex = 36
        Me.GroupDoctor.TabStop = False
        Me.GroupDoctor.Text = "Dr."
        '
        'ComboHorario
        '
        Me.ComboHorario.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboHorario.FormattingEnabled = True
        Me.ComboHorario.Location = New System.Drawing.Point(127, 103)
        Me.ComboHorario.Name = "ComboHorario"
        Me.ComboHorario.Size = New System.Drawing.Size(133, 28)
        Me.ComboHorario.TabIndex = 37
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Font = New System.Drawing.Font("Franklin Gothic Demi", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.Location = New System.Drawing.Point(50, 99)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(71, 24)
        Me.Label13.TabIndex = 36
        Me.Label13.Text = "Horario"
        '
        'EspecialidadTableAdapter
        '
        Me.EspecialidadTableAdapter.ClearBeforeFill = True
        '
        'ConsultorioTableAdapter
        '
        Me.ConsultorioTableAdapter.ClearBeforeFill = True
        '
        'HospitalHorario
        '
        Me.HospitalHorario.DataSetName = "HospitalHorario"
        Me.HospitalHorario.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'HorarioBindingSource
        '
        Me.HorarioBindingSource.DataMember = "Horario"
        Me.HorarioBindingSource.DataSource = Me.HospitalHorario
        '
        'HorarioTableAdapter
        '
        Me.HorarioTableAdapter.ClearBeforeFill = True
        '
        'frmNewUsuario
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Snow
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.GroupDoctor)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.comboTipo)
        Me.Controls.Add(Me.CalFechaNac)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.txtCorreo)
        Me.Controls.Add(Me.txtTel)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.txtMaterno)
        Me.Controls.Add(Me.txtPaterno)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.txtName)
        Me.Controls.Add(Me.cmdNew)
        Me.Controls.Add(Me.txtPass)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.txtUser)
        Me.Name = "frmNewUsuario"
        Me.Text = "Nuevo Usuario"
        CType(Me.RolBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Hospital_Rol, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.HospitalDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.HospitalDataSetBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.HospitalDataSetBindingSource1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.EspecialidadBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.HospitalDataSet1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ConsultorioBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.HospitalConsultorio, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupDoctor.ResumeLayout(False)
        Me.GroupDoctor.PerformLayout()
        CType(Me.HospitalHorario, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.HorarioBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents cmdNew As Windows.Forms.Button
    Friend WithEvents txtPass As Windows.Forms.TextBox
    Friend WithEvents Label3 As Windows.Forms.Label
    Friend WithEvents Label2 As Windows.Forms.Label
    Friend WithEvents Label1 As Windows.Forms.Label
    Friend WithEvents txtUser As Windows.Forms.TextBox
    Friend WithEvents txtPaterno As Windows.Forms.TextBox
    Friend WithEvents Label4 As Windows.Forms.Label
    Friend WithEvents Label5 As Windows.Forms.Label
    Friend WithEvents txtName As Windows.Forms.TextBox
    Friend WithEvents Label6 As Windows.Forms.Label
    Friend WithEvents Label7 As Windows.Forms.Label
    Friend WithEvents txtCorreo As Windows.Forms.TextBox
    Friend WithEvents txtTel As Windows.Forms.TextBox
    Friend WithEvents Label8 As Windows.Forms.Label
    Friend WithEvents Label9 As Windows.Forms.Label
    Friend WithEvents txtMaterno As Windows.Forms.TextBox
    Friend WithEvents CalFechaNac As Windows.Forms.DateTimePicker
    Friend WithEvents comboTipo As Windows.Forms.ComboBox
    Friend WithEvents Label10 As Windows.Forms.Label
    Friend WithEvents HospitalDataSetBindingSource1 As Windows.Forms.BindingSource
    Friend WithEvents HospitalDataSet As HospitalDataSet
    Friend WithEvents HospitalDataSetBindingSource As Windows.Forms.BindingSource
    Friend WithEvents Hospital_Rol As Hospital_Rol
    Friend WithEvents RolBindingSource As Windows.Forms.BindingSource
    Friend WithEvents RolTableAdapter As Hospital_RolTableAdapters.RolTableAdapter
    Friend WithEvents Label11 As Windows.Forms.Label
    Friend WithEvents comboEspe As Windows.Forms.ComboBox
    Friend WithEvents Label12 As Windows.Forms.Label
    Friend WithEvents comboCons As Windows.Forms.ComboBox
    Friend WithEvents GroupDoctor As Windows.Forms.GroupBox
    Friend WithEvents ComboHorario As Windows.Forms.ComboBox
    Friend WithEvents Label13 As Windows.Forms.Label
    Friend WithEvents HospitalDataSet1 As HospitalDataSet1
    Friend WithEvents EspecialidadBindingSource As Windows.Forms.BindingSource
    Friend WithEvents EspecialidadTableAdapter As HospitalDataSet1TableAdapters.EspecialidadTableAdapter
    Friend WithEvents HospitalConsultorio As HospitalConsultorio
    Friend WithEvents ConsultorioBindingSource As Windows.Forms.BindingSource
    Friend WithEvents ConsultorioTableAdapter As HospitalConsultorioTableAdapters.ConsultorioTableAdapter
    Friend WithEvents HospitalHorario As HospitalHorario
    Friend WithEvents HorarioBindingSource As Windows.Forms.BindingSource
    Friend WithEvents HorarioTableAdapter As HospitalHorarioTableAdapters.HorarioTableAdapter
End Class
