﻿Imports System.Data
Imports System.Data.SqlClient
Imports System.Windows.Forms

Public Class frmInicioPac
    Private Sub cmdHistorial_Click(sender As Object, e As EventArgs) Handles cmdHistorial.Click
        Dim frmHist As New frmHistorial
        frmHist.Show()
        Hide()
    End Sub

    Private Sub frmInicioPac_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim cn As New DB_Class
        Try
            Dim queryName As String = "SELECT 'Bienvenido, ' + Nombre + ' ' + Paterno AS Nombre FROM Usuario WHERE ID_Usuario = '" & user & "'"
            Dim dtName As DataTable = cn.EjecutarConsulta(queryName)
            If cn.Err Then
                MsgBox(cn.ErrMessage)
            Else
                Me.lblNombre.Text = dtName.Rows(0).Item("Nombre")
            End If
        Catch ex As Exception
            MessageBox.Show("Error: " & ex.Message)
        End Try
    End Sub

End Class