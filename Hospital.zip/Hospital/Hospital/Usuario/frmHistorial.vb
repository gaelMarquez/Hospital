﻿Imports System.Data
Imports System.Windows.Forms

Public Class frmHistorial
    Private Sub frmHistorial_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim cn As New DB_Class
        Try
            Dim query As String = "SELECT ID_Cita, FORMAT(Fecha, 'yyyy-MM-dd HH:mm:ss') AS Fecha FROM Cita WHERE ID_Estado = 2 AND ID_Paciente = '" & user & "'"
            Dim dt As DataTable = cn.EjecutarConsulta(query)
            If cn.Err Then
                MsgBox(cn.ErrMessage)
            Else
                Me.DataHistorial.DataSource = dt
            End If
            Dim queryName As String = "SELECT 'Historial Médico de: ' + Nombre + ' ' + Paterno AS Titulo FROM Usuario WHERE ID_Usuario = '" & user & "'"
            Dim dtName As DataTable = cn.EjecutarConsulta(queryName)
            If cn.Err Then
                MsgBox(cn.ErrMessage)
            Else
                Me.lblTitulo.Text = dtName.Rows(0).Item("Titulo")
            End If
        Catch ex As Exception
            MessageBox.Show("Error: " & ex.Message)
        End Try
    End Sub

    Private Sub DataGridView1_SelectionChanged(sender As Object, e As EventArgs) Handles DataHistorial.SelectionChanged
        Dim cn As New DB_Class
        Dim idCita As String = Me.DataHistorial.Rows(sender.CurrentRow.index).Cells(0).Value
        'Me.TextBox2.Text = Me.DataHistorial.Rows(sender.CurrentRow.index).Cells(1).Value
        Try
            Dim query As String = "SELECT * FROM Informacion_Cita WHERE ID_Usuario = '" & user & "' AND ID_Cita= '" & idCita & "'"
            Dim dt As DataTable = cn.EjecutarConsulta(query)
            If cn.Err Then
                MsgBox(cn.ErrMessage)
            Else
                Me.lblNombre.Text = dt.Rows(0).Item("Doctor")
                Me.lblConsultorio.Text = dt.Rows(0).Item("Numero")
                Me.lblDiagnostico.Text = dt.Rows(0).Item("Diagnostico")
                Me.lblMedicina.Text = dt.Rows(0).Item("Medicamento")
            End If
        Catch ex As Exception

        End Try
    End Sub
End Class