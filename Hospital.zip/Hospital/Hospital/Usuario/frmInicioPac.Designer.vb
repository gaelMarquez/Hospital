﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmInicioPac
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.RolBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.HospitalRolBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.Hospital_Rol = New Hospital.Hospital_Rol()
        Me.RolTableAdapter = New Hospital.Hospital_RolTableAdapters.RolTableAdapter()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.TextBox2 = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.lblNombre = New System.Windows.Forms.Label()
        Me.cmdHistorial = New System.Windows.Forms.Button()
        Me.cmdCita = New System.Windows.Forms.Button()
        Me.cmdOpciones = New System.Windows.Forms.Button()
        CType(Me.RolBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.HospitalRolBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Hospital_Rol, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'RolBindingSource
        '
        Me.RolBindingSource.DataMember = "Rol"
        Me.RolBindingSource.DataSource = Me.HospitalRolBindingSource
        '
        'HospitalRolBindingSource
        '
        Me.HospitalRolBindingSource.DataSource = Me.Hospital_Rol
        Me.HospitalRolBindingSource.Position = 0
        '
        'Hospital_Rol
        '
        Me.Hospital_Rol.DataSetName = "Hospital_Rol"
        Me.Hospital_Rol.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'RolTableAdapter
        '
        Me.RolTableAdapter.ClearBeforeFill = True
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(551, 37)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(100, 20)
        Me.TextBox1.TabIndex = 1
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(551, 18)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(37, 13)
        Me.Label1.TabIndex = 2
        Me.Label1.Text = "ID Rol"
        '
        'TextBox2
        '
        Me.TextBox2.Location = New System.Drawing.Point(688, 36)
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.Size = New System.Drawing.Size(100, 20)
        Me.TextBox2.TabIndex = 3
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(688, 18)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(23, 13)
        Me.Label2.TabIndex = 4
        Me.Label2.Text = "Rol"
        '
        'lblNombre
        '
        Me.lblNombre.AutoSize = True
        Me.lblNombre.Font = New System.Drawing.Font("Franklin Gothic Demi", 14.25!)
        Me.lblNombre.Location = New System.Drawing.Point(12, 9)
        Me.lblNombre.Name = "lblNombre"
        Me.lblNombre.Size = New System.Drawing.Size(15, 24)
        Me.lblNombre.TabIndex = 5
        Me.lblNombre.Text = "."
        '
        'cmdHistorial
        '
        Me.cmdHistorial.Font = New System.Drawing.Font("Franklin Gothic Demi", 12.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdHistorial.Location = New System.Drawing.Point(300, 184)
        Me.cmdHistorial.Name = "cmdHistorial"
        Me.cmdHistorial.Size = New System.Drawing.Size(144, 32)
        Me.cmdHistorial.TabIndex = 7
        Me.cmdHistorial.Text = "Historial Médico"
        Me.cmdHistorial.UseVisualStyleBackColor = True
        '
        'cmdCita
        '
        Me.cmdCita.Font = New System.Drawing.Font("Franklin Gothic Demi", 12.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdCita.Location = New System.Drawing.Point(300, 232)
        Me.cmdCita.Name = "cmdCita"
        Me.cmdCita.Size = New System.Drawing.Size(144, 32)
        Me.cmdCita.TabIndex = 8
        Me.cmdCita.Text = "Ver/Cancelar Cita"
        Me.cmdCita.UseVisualStyleBackColor = True
        '
        'cmdOpciones
        '
        Me.cmdOpciones.Font = New System.Drawing.Font("Franklin Gothic Demi", 12.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdOpciones.Location = New System.Drawing.Point(300, 279)
        Me.cmdOpciones.Name = "cmdOpciones"
        Me.cmdOpciones.Size = New System.Drawing.Size(144, 32)
        Me.cmdOpciones.TabIndex = 9
        Me.cmdOpciones.Text = "Configuración"
        Me.cmdOpciones.UseVisualStyleBackColor = True
        '
        'frmInicioPac
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Snow
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.cmdOpciones)
        Me.Controls.Add(Me.cmdCita)
        Me.Controls.Add(Me.cmdHistorial)
        Me.Controls.Add(Me.lblNombre)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.TextBox2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.TextBox1)
        Me.Name = "frmInicioPac"
        Me.Text = "Inicio"
        CType(Me.RolBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.HospitalRolBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Hospital_Rol, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents HospitalRolBindingSource As Windows.Forms.BindingSource
    Friend WithEvents Hospital_Rol As Hospital_Rol
    Friend WithEvents RolBindingSource As Windows.Forms.BindingSource
    Friend WithEvents RolTableAdapter As Hospital_RolTableAdapters.RolTableAdapter
    Friend WithEvents TextBox1 As Windows.Forms.TextBox
    Friend WithEvents Label1 As Windows.Forms.Label
    Friend WithEvents TextBox2 As Windows.Forms.TextBox
    Friend WithEvents Label2 As Windows.Forms.Label
    Friend WithEvents lblNombre As Windows.Forms.Label
    Friend WithEvents cmdHistorial As Windows.Forms.Button
    Friend WithEvents cmdCita As Windows.Forms.Button
    Friend WithEvents cmdOpciones As Windows.Forms.Button
End Class
