﻿Imports System.ComponentModel
Imports System.Data
Public Class frmLogIn
    Private Sub btInicio_Click(sender As Object, e As EventArgs) Handles cmdInicio.Click
        Dim conexion As New DB_Class
        Dim res As New DataTable
        user = Me.txtUser.Text
        res = conexion.EjecutarConsulta("SELECT ID_Rol FROM Usuario WHERE ID_Usuario='" & user & "' AND Password='" & Me.txtPass.Text & "'")
        If res.Rows.Count > 0 Then
            Select Case res.Rows(0).Item("ID_Rol")
                Case 1
                    Dim frmPac = New frmInicioPac
                    frmPac.Show()
                    Hide()
                Case 2

                Case 3
                    Dim frmDoc = New frmDoctor
                    frmDoc.Show()
                    Hide()

            End Select
        Else
            MsgBox("Usuario no encontrado o contraseña incorrecta.")
        End If
        conexion = Nothing
    End Sub

    Private Sub cmdNew_Click(sender As Object, e As EventArgs) Handles cmdNew.Click
        Dim _formCrear As New frmNewUsuario
        _formCrear.Show()
        Hide()
    End Sub
End Class